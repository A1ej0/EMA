from flask import Flask, render_template, request, url_for , abort, redirect
import os

app = Flask(__name__)
IMG_FOLDER = os.path.join("static", "IMG")
app.config['UPLOAD_FOLDER'] = IMG_FOLDER

@app.route('/')
def hello():
    return 'Hello, World!'

@app.route('/index', methods=['GET', 'POST'])
def inicio():
    imagen1 = os.path.join(app.config["UPLOAD_FOLDER"], "imagen1.jpg")
    logo = os.path.join(app.config["UPLOAD_FOLDER"], "logo.ico")

    return render_template("index.html" , imagen1 = imagen1, logo = logo) 
@app.route('/index/dashboard', methods=['GET', 'POST'])
def dashboard():
    logo = os.path.join(app.config["UPLOAD_FOLDER"], "../logo.ico")
    return render_template("dashboard.html" , logo = logo)

@app.route('/index1', methods=['GET', 'POST'])
def inicio1():
    a = "index1.html"
    if request.method == 'POST':
        if request.form.get("action") == "Generar":
            a="index.html"
            #ir a la ruta /carga
            return redirect(url_for('inicio'))
        else:
            return render_template(a)
    else:
        return render_template(a)


@app.route('/carga', methods=['GET', 'POST'])
def cargar():

    return render_template("carga.html" )

if __name__ == '__main__':
    app.debug = True

    app.run()