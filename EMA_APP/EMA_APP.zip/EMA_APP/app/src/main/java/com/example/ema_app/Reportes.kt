package com.example.ema_app

import android.Manifest.permission.READ_EXTERNAL_STORAGE
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.csvconvertor.CsvConverter
import com.example.ema_app.ui.theme.EMA_APPTheme
import com.itextpdf.text.Document
import com.itextpdf.text.Element
import com.itextpdf.text.PageSize
import com.itextpdf.text.pdf.PdfPTable
import com.itextpdf.text.pdf.PdfWriter
import java.io.File
import java.io.FileOutputStream


class Reportes : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (checkPermissions()) {
            setContent {
                EMA_APPTheme {
                    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                        Reports(
                            name = "Android",
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
        //Otherwise request permission
        else {
            requestPermissions();
        }

    }

    @Deprecated("This method has been deprecated in favor of using the Activity Result API\n      which brings increased type safety via an {@link ActivityResultContract} and the prebuilt\n      contracts for common intents available in\n      {@link androidx.activity.result.contract.ActivityResultContracts}, provides hooks for\n      testing, and allow receiving results in separate, testable classes independent from your\n      activity. Use\n      {@link #registerForActivityResult(ActivityResultContract, ActivityResultCallback)} passing\n      in a {@link RequestMultiplePermissions} object for the {@link ActivityResultContract} and\n      handling the result in the {@link ActivityResultCallback#onActivityResult(Object) callback}.")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
        } else {
            setContent {
                EMA_APPTheme {
                    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                        Reports(
                            name = "Android",
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }
    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(READ_EXTERNAL_STORAGE),
            1
        )
    }
    private fun checkPermissions(): Boolean {
        val result = ContextCompat.checkSelfPermission(applicationContext, READ_EXTERNAL_STORAGE)
        return result == PackageManager.PERMISSION_GRANTED
    }


}

@Composable
fun Reports(name: String, modifier: Modifier = Modifier) {
    val context= LocalContext.current
    Box(
        modifier = modifier
    ) {
        Image(
            painter = painterResource(id = R.drawable.imagen11),
            contentDescription = "imagen1 1",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize())
        Box(
            modifier = Modifier
                .align(alignment = Alignment.Center)
                .offset(
                    x = 0.dp,
                    y = 70.dp
                )
        ) {
            Box(
                modifier = Modifier
                    .align(alignment = Alignment.TopCenter)
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.8f)
                    .clip(shape = RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp))
                    .background(color = Color(0xE6f7e9e9))

            ) {
                Text(
                    text = "Reportes",
                    color = Color(0xff2d0c57),
                    textAlign = TextAlign.Center,
                    lineHeight = 1.21.em,
                    style = TextStyle(
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.41.sp
                    ),
                    modifier = Modifier
                        .align(alignment = Alignment.TopCenter)
                        .offset(
                            x = 0.dp,
                            y = 50.dp
                        )
                )
                AnimatedPreloader(modifier = Modifier
                    .size(100.dp)
                    .align(Alignment.Center)
                    .offset(x = 0.dp, y = (-130).dp),R.raw.animdb)
                Row(
                    modifier = Modifier
                        .align(alignment = Alignment.Center)
                        .offset(
                            y = 0.dp
                        )
                ) {
                    ElevatedButton(
                        onClick = {exportCSV( context)},
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xa0d793e6)),
                        modifier = Modifier

                            .offset(x = 0.dp, y = 0.dp)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "CSV",
                            color = Color(0xff2d0c57),
                            style = TextStyle(
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.41.sp
                            )
                        )
                    }
                    ElevatedButton(
                        onClick = {exportPDF( context)},
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xa0d793e6)),
                        modifier = Modifier

                            .offset(x = 0.dp, y = 0.dp)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "PDF",
                            color = Color(0xff2d0c57),
                            style = TextStyle(
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.41.sp
                            )
                        )
                    }
                }

            }
        }

    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview2() {
    EMA_APPTheme {
        Reports("Android")
    }
}

fun exportCSV(context : Context) {


    val path = context.filesDir

    val letDirectory = File(path, "LET")
    letDirectory.mkdirs()
    val file = File(letDirectory, "reportes.csv")
    file.delete()
    file.createNewFile()

    FileOutputStream(file).use {
        connectToDatabase()?.let {
            val statement = it.createStatement()
            val resultSet = statement.executeQuery("SELECT LoRa,dist,fecha FROM sensador WHERE fecha >= '${fecha1.value.toString()}' and fecha <= '${fecha2.value.toString()}'")
            var pruebas = 0
            QualityDB.clear()
            DistanciaDB.clear()
            fechaDB.clear()
            QualityDB.add("Calidad de agua:")
            DistanciaDB.add("Distancia:")
            fechaDB.add("Fecha y hora:")
            while (resultSet.next()) {
                QualityDB.add(resultSet.getString("LoRa"))
                DistanciaDB.add(resultSet.getString("dist"))
                fechaDB.add(resultSet.getString("fecha"))
                Log.d("TestDB", "iteracion: $pruebas")
                pruebas++
            }
            Log.d("TestDB", "QualityDB1: $QualityDB")
            Log.d("TestDB", "DistanciaDB1: $DistanciaDB")
        }
        it.write("Fecha y hora,Distancia,Calidad de agua\n".toByteArray())
        for (i in 1 until QualityDB.size) {
            it.write("${fechaDB[i]},${DistanciaDB[i]},${QualityDB[i]}\n".toByteArray())
        }
    }
    try {
        if(file.exists()) {
            val uri = FileProvider.getUriForFile(context, context.applicationContext.packageName + ".provider", file)
            val intent = Intent(Intent.ACTION_SEND)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.setType("*/*")
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent)
        }
    } catch (e: java.lang.Exception) {
        e.printStackTrace()
        Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show()
    }

}


fun exportPDF(context : Context) {

    val path = context.filesDir


    val letDirectory = File(path, "LET")
    letDirectory.mkdirs()
    val file = File(letDirectory, "reportes.pdf")
    file.delete()
    file.createNewFile()

    FileOutputStream(file).use {
        connectToDatabase()?.let {
            val statement = it.createStatement()
            val resultSet = statement.executeQuery("SELECT LoRa,dist,fecha FROM sensador WHERE fecha >= '${fecha1.value.toString()}' and fecha <= '${fecha2.value.toString()}'")
            var pruebas = 0
            QualityDB.clear()
            DistanciaDB.clear()
            fechaDB.clear()
            QualityDB.add("Calidad de agua:")
            DistanciaDB.add("Distancia:")
            fechaDB.add("Fecha y hora:")
            while (resultSet.next()) {
                QualityDB.add(resultSet.getString("LoRa"))
                DistanciaDB.add(resultSet.getString("dist"))
                fechaDB.add(resultSet.getString("fecha"))
                Log.d("TestDB", "iteracion: $pruebas")
                pruebas++
            }
            Log.d("TestDB", "QualityDB1: $QualityDB")
            Log.d("TestDB", "DistanciaDB1: $DistanciaDB")
        }

        val document = Document()
        document.setMargins(24f, 24f, 32f, 32f)
        document.pageSize = PageSize.A4

        var pdf = PdfWriter.getInstance(document, FileOutputStream(file))
        pdf.setFullCompression()
        document.open()
        document.addTitle("Reporte de datos")
        document.addSubject("Reporte de datos")
        document.addKeywords("Reporte de datos")
        document.addAuthor("EMA")
        document.addCreator("EMA")
        document.addCreationDate()

        val table = createTable(3, floatArrayOf(3f, 3f, 3f))
        table.addCell("Fecha y hora")
        table.addCell("Distancia")
        table.addCell("Calidad de agua")
        for (i in 1 until QualityDB.size) {
            table.addCell(fechaDB[i])
            table.addCell(DistanciaDB[i])
            table.addCell(QualityDB[i])
        }
        document.add(table)
        document.close()
        pdf.close()
    }
    try {
        if(file.exists()) {
            val uri = FileProvider.getUriForFile(context, context.applicationContext.packageName + ".provider", file)
            val intent = Intent(Intent.ACTION_SEND)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.setType("*/*")
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent)
        }
    } catch (e: java.lang.Exception) {
        e.printStackTrace()
        Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show()
    }


}


fun createTable(column: Int, columnWidth: FloatArray): PdfPTable {
    val table = PdfPTable(column)
    table.widthPercentage = 100f
    table.setWidths(columnWidth)
    table.headerRows = 1
    table.defaultCell.verticalAlignment = Element.ALIGN_CENTER
    table.defaultCell.horizontalAlignment = Element.ALIGN_CENTER
    return table
}

